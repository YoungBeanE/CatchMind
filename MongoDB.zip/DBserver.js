const express = require("express");
const mongoose = require("mongoose");
const app = express(); //express앱 한개 생성
app.use(express.json()); //express.json 미들웨어 사용
app.set("port", 8080);

var password = encodeURIComponent("YBDB");
mongoose.connect(`mongodb://YB:${password}@127.0.0.1:27017/?authMechanism=DEFAULT&authSource=admin&directConnection=true`, {dbName: "users"});

const db = mongoose.connection;
db.on('error', () => {console.log('Connection Failed');});
db.once('open', () => {console.log('Connected');});
app.listen(app.get("port"), () => {console.log('Server is running at port ', app.get("port"));});

var userSchema = mongoose.Schema(
    {
    id: {type:String, required:true, unique:true},
    password: {type:String, required:true},
    name: {type:String, required:true},
    email: {type:String, required:true},
    level: {type:String, required:true}
},{versionKey:false});

var Users = mongoose.model('user', userSchema, "userList");

//유저정보 로드
app.get("/getuserlist", (req, res) => 
{
    Users.find({}, (error, userList) => 
    {
        if(error){
            console.log(error);
        }
        else{
            let jsonStr = JSON.stringify(userList);
            console.log(jsonStr);
            res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
            res.end(jsonStr);
        }
    });
});

//아이디 중복체크
app.get('/checkid/:id', function(req, res)
{
    Users.findOne({id:req.params.id}, (error, userList) => {
        if(error)
        {
            console.log(error);
            res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            if(userList === null)
            {
                console.log("유저정보 없음");
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('can');
            }
            else
            {
                console.log("유저정보 있음");
                console.log(userList);
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('cannot');
            }
        }
    });
});

//로그인요청
app.get('/sigin/:id/:password', (req, res) => 
{
    Users.findOne({$and: [{id:req.params['id']}, {password:req.params['password']}]}, (error, userList) => 
    {
        if(error)
        {
            console.log(error);
            res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            if(userList === null)
            {
                console.log("유저정보 없음");
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('notfound');
            }
            else
            {
                console.log("유저정보 있음");
                let jsonStr = JSON.stringify(userList);
                console.log(jsonStr);
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end(jsonStr);
            }
        }
    });
});

//아이디찾기
app.get('/findid/:name/:email', (req, res) => 
{
    Users.findOne({$and: [{name:req.params['name']}, {email:req.params['email']}]}, (error, userList) => 
    {
        if(error)
        {
            console.log(error);
            res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            if(userList === null)
            {
                console.log("유저정보 없음");
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('notfound');
            }
            else
            {
                console.log("유저정보 있음");
                let jsonStr = JSON.stringify(userList);
                console.log(jsonStr);
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end(jsonStr);
            }
        }
    });
});

//비밀번호찾기
app.get('/findpwd/:id/:name/:email', (req, res) => 
{
    Users.findOne({$and: [{id:req.params['id']}, {name:req.params['name']}, {email:req.params['email']}]}, (error, userList) => 
    {
        if(error)
        {
            console.log(error);
            res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            if(userList === null)
            {
                console.log("유저정보 없음");
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('notfound');
            }
            else
            {
                console.log("유저정보 있음");
                let jsonStr = JSON.stringify(userList);
                console.log(jsonStr);
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end(jsonStr);
            }
        }
    });
});

//회원가입
app.post('/signup', (req, res) => 
{
    var newUser = new Users({id:req.body['id'], password:req.body['password'], name:req.body['name'], email:req.body['email'], level:req.body['level']});
    newUser.save((error, data) => 
    {
        if(error){
            console.log(error);
            res.writeHead(400, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else{
            console.log('유저데이터 추가');
            res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
            res.end('ok');
            console.log(newUser);
        }
    });
});

//레벨업
app.post('/levelup', (req, res) => 
{
    Users.findOne({id:req.body['id']}, (error, userList) => 
    {
        if(error)
        {
            console.log(error);
            res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            if(userList === null)
            {
                console.log("유저정보 없음");
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('null');
            }
            else
            {
                console.log(userList);
                userList.level = req.body['level'];
                userList.save((error, data) => 
                {
                    if(error)
                    {
                        console.log(error);
                        res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
                        res.end('error');
                    }
                    else
                    {
                        console.log('유저데이터 정보 수정');
                        res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                        res.end('up');
                    }
                });
            }
            console.log(userList);
        }
    });
});

//가입탈퇴
app.post('/withdraw', (req, res) => 
{
    Users.deleteOne({$and: [{id:req.body['id']}, {password:req.body['password']}]}, (error, userList) => 
    {
        if(error)
        {
            console.log(error);
            console.log("유저정보 없음");
            res.writeHead(400, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            console.log('해당 유저데이터 삭제');
            res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
            res.end('delete');
        }
    });
});