const express = require("express");
//const nodemailer = require('nodemailer');
const app = express(); //express앱  생성
app.use(express.json()); //express.json 미들웨어 사용
app.set("port", 8080);
app.listen(app.get("port"), () => {console.log('Server is running at port ', app.get("port"));});

const mongoose = require("mongoose");
var password = encodeURIComponent("YBDB");
mongoose.connect(`mongodb://YB:${password}@127.0.0.1:27017/?directConnection=true&authMechanism=DEFAULT`, {dbName: "UserData"});
//172.16.1.239
const db = mongoose.connection;
db.on('error', () => {console.log('Connection Failed');});
db.once('open', () => {console.log('Connected');});


var userSchema = mongoose.Schema(
    {
    id: {type:String, required:true, unique:true},
    password: {type:String, required:true},
    name: {type:String, required:true},
    email: {type:String, required:true},
    level: {type:String, required:true}
},{versionKey:false});

var Users = mongoose.model('user', userSchema, "UserList");

//유저정보 로드
app.get("/getuserlist", (req, res) => 
{
    Users.find({}, (error, userList) => 
    {
        if(error){
            console.log(error);
        }
        else{
            let jsonStr = JSON.stringify(userList);
            console.log(jsonStr);
            res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
            res.end(jsonStr);
        }
    });
});

//키워드
app.get("/keywordlist", (req, res) => 
{
    request().then((data) => {
        res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
        res.end(data);
    });
    
});

async function request() 
    {
        try {
            const response = await fetch('https://www.11st.co.kr/AutoCompleteAjaxAction.tmall?method=getKeywordRankJson&type=hot&isSSL=Y&rankCnt=200&callback=fetchSearchRanking',
            {
            method: 'GET',
            });

            const data = await response.text();


            const a = data.indexOf('({');
            const b = data.indexOf('})');
            const editdata = data.substring(a +1, b +1);
            let jsondata = JSON.parse(editdata);
            let keyword = "";

            for (var i = 0; i < jsondata.items.length; i++)
            {
                if(i == 0)
                {
                    keyword += jsondata.items[i].keyword;
                }
                else
                {
                    keyword += ',' + jsondata.items[i].keyword;
                }
            }
            return keyword;
            } catch(error)
            {
              console.log(error);
            }
};

//아이디 중복체크
app.get('/checkid/:id', function(req, res)
{
    Users.findOne({id:req.params.id}, (error, userList) => {
        if(error)
        {
            console.log(error);
            res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            if(userList === null)
            {
                console.log("유저정보 없음");
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('can');
            }
            else
            {
                console.log("유저정보 있음");
                console.log(userList);
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('cannot');
            }
        }
    });
});

//로그인요청
app.get('/sigin/:id/:password', (req, res) => 
{
    Users.findOne({$and: [{id:req.params['id']}, {password:req.params['password']}]}, (error, userList) => 
    {
        if(error)
        {
            console.log(error);
            res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            if(userList === null)
            {
                console.log("유저정보 없음");
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('notfound');
            }
            else
            {
                console.log("유저정보 있음");
                let jsonStr = JSON.stringify(userList);
                console.log(jsonStr);
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end(jsonStr);
            }
        }
    });
});

//아이디찾기
app.get('/findid/:name/:email', (req, res) => 
{
    Users.findOne({$and: [{name:req.params['name']}, {email:req.params['email']}]}, (error, userList) => 
    {
        if(error)
        {
            console.log(error);
            res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            if(userList === null)
            {
                console.log("유저정보 없음");
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('notfound');
            }
            else
            {
                console.log("유저정보 있음");
                let jsonStr = JSON.stringify(userList);
                console.log(jsonStr);
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end(jsonStr);
            }
        }
    });
});

//비밀번호찾기
app.get('/findpwd/:id/:name/:email', (req, res) => 
{
    Users.findOne({$and: [{id:req.params['id']}, {name:req.params['name']}, {email:req.params['email']}]}, (error, userList) => 
    {
        if(error)
        {
            console.log(error);
            res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            if(userList === null)
            {
                console.log("유저정보 없음");
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('notfound');
            }
            else
            {
                console.log("유저정보 있음");
                let jsonStr = JSON.stringify(userList);
                console.log(jsonStr);
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end(jsonStr);
            }
        }
    });
});

//회원가입
app.post('/signup', (req, res) => 
{
    var newUser = new Users({id:req.body['id'], password:req.body['password'], name:req.body['name'], email:req.body['email'], level:req.body['level']});
    newUser.save((error, data) => 
    {
        if(error){
            console.log(error);
            res.writeHead(400, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else{
            console.log('유저데이터 추가');
            res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
            res.end('ok');
            console.log(newUser);
        }
    });
});

//레벨업
app.post('/levelup', (req, res) => 
{
    Users.findOne({id:req.body['id']}, (error, userList) => 
    {
        if(error)
        {
            console.log(error);
            res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            if(userList === null)
            {
                console.log("유저정보 없음");
                res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                res.end('null');
            }
            else
            {
                userList.level = req.body['level'];
                userList.save((error, data) => 
                {
                    if(error)
                    {
                        console.log(error);
                        res.writeHead(404, {"Content-Type":"application/json;charset=utf-8"});
                        res.end('error');
                    }
                    else
                    {
                        console.log('유저데이터 정보 수정');
                        res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
                        res.end('up');
                    }
                });
            }
        }
    });
});

//가입탈퇴
app.post('/withdraw', (req, res) => 
{
    Users.deleteOne({$and: [{id:req.body['id']}, {password:req.body['password']}]}, (error, userList) => 
    {
        if(error)
        {
            console.log(error);
            console.log("유저정보 없음");
            res.writeHead(400, {"Content-Type":"application/json;charset=utf-8"});
            res.end('error');
        }
        else
        {
            console.log('해당 유저데이터 삭제');
            res.writeHead(200, {"Content-Type":"application/json;charset=utf-8"});
            res.end('delete');
        }
    });
});